<?php $__env->startSection('parentPageTitle', 'App'); ?>
<?php $__env->startSection('title2', 'Inbox'); ?>
<?php $__env->startSection('title', 'Compose'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="body">
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="To">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Subject">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="CC">
                    </div>
                </form>
                <hr>
                <div class="summernote">
                    Hello there,
                    <br/>
                    <p>The toolbar can be customized and it also supports various callbacks such as <code>oninit</code>, <code>onfocus</code>, <code>onpaste</code> and many more.</p>
                    <p>Please try <b>paste some texts</b> here</p>
                </div>
                <div class="m-t-30">
                    <button type="button" class="btn btn-success">Send Message</button>
                    <button type="button" class="btn btn-secondary">Draft</button>
                    <a href="app-inbox.html" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/summernote/dist/summernote.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/vendor/summernote/dist/summernote.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>