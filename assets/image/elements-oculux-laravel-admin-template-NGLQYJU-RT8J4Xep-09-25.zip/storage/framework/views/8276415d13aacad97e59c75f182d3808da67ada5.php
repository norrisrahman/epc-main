<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon"> <!-- Favicon-->
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', config('app.name')); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', config('app.name')); ?>">
    <?php echo $__env->yieldContent('meta'); ?>

    <?php echo $__env->yieldPushContent('before-styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate-css/vivify.min.css')); ?>">    

    <?php echo $__env->yieldPushContent('after-styles'); ?>    
    <?php if(trim($__env->yieldContent('page-styles'))): ?>    
        <?php echo $__env->yieldContent('page-styles'); ?>
    <?php endif; ?>    
    <!-- Custom Css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/site.min.css')); ?>">
</head>

<body class="theme-cyan font-montserrat">
    
<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <div class="bar4"></div>
        <div class="bar5"></div>
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>

<!-- Scripts -->
<?php echo $__env->yieldPushContent('before-scripts'); ?>

<script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>

<?php echo $__env->yieldPushContent('after-scripts'); ?>

<?php if(trim($__env->yieldContent('page-script'))): ?>
    <?php echo $__env->yieldContent('page-script'); ?>
<?php endif; ?>
    
</body>
</html>
