<?php $__env->startSection('title', 'Events'); ?>
<?php $__env->startSection('parentPageTitle', 'App'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-8">
        <div class="card">
            <div class="body">
                <div id="calendar"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="body">
                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#addevent">Add New Event</button>
            </div>
        </div>
        <div class="card">
            <div class="body">
                <div class="event-name row">
                    <div class="col-2 text-center">
                        <h4>11<span>Dec</span><span>2018</span></h4>
                    </div>
                    <div class="col-10">
                        <h6>Conference</h6>
                        <p>Mobile World Congress 2018</p>
                        <address><i class="fa fa-map-marker"></i> 4 Goldfield Rd. Honolulu, HI 96815</address>
                    </div>
                </div>                            
                <div class="event-name row">
                    <div class="col-2 text-center">
                        <h4>13<span>Dec</span><span>2018</span></h4>
                    </div>
                    <div class="col-10">
                        <h6>Birthday</h6>
                        <p>Today, guests are getting in on the action</p>
                        <address><i class="fa fa-map-marker"></i> 4 Goldfield Rd. Honolulu, HI 96815</address>
                    </div>
                </div>
                <hr>
                <div class="event-name row">
                    <div class="col-2 text-center">
                        <h4>09<span>Dec</span><span>2018</span></h4>
                    </div>
                    <div class="col-10">
                        <h6>Repeating Event</h6>
                        <p>Before there were tech conferences, there was Disrupt.</p>
                        <address><i class="fa fa-map-marker"></i> 44 Shirley Ave. West Chicago, IL 60185</address>
                    </div>
                </div>
                <hr>
                <div class="event-name row">
                    <div class="col-2 text-center">
                        <h4>16<span>Dec</span><span>2018</span></h4>
                    </div>
                    <div class="col-10">
                        <h6>Repeating Event</h6>
                        <p>It is a long established fact that a reader will be distracted</p>
                        <address><i class="fa fa-map-marker"></i> 123 6th St. Melbourne, FL 32904</address>
                    </div>
                </div>
                <div class="event-name row">
                    <div class="col-2 text-center">
                        <h4>28<span>Dec</span><span>2018</span></h4>
                    </div>
                    <div class="col-10">
                        <h6>Google</h6>
                        <p>Google Hardware and Pixel 2 Launch</p>
                        <address><i class="fa fa-map-marker"></i> 514 S. Magnolia St. Orlando, FL 32806</address>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Default Size -->
<div class="modal animated jello" id="addevent" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="defaultModalLabel">Add Event</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div class="form-line">
                        <input type="number" class="form-control" placeholder="Event Date">
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-line">
                        <input type="text" class="form-control" placeholder="Event Title">
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-line">
                        <textarea class="form-control no-resize" rows="4" placeholder="Event Description..."></textarea>
                    </div>
                </div>       
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Add</button>
                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fullcalendar/fullcalendar.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/fullcalendarscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/fullcalendar/fullcalendar.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/calendar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>