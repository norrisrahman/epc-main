<?php $__env->startSection('title', 'Holidays'); ?>
<?php $__env->startSection('parentPageTitle', 'App'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                <h2>List</h2>
                <ul class="header-dropdown">
                    <li><a href="javascript:void(0);" class="btn btn-info" data-toggle="modal" data-target="#add_user">Add User</a></li>
                </ul>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-hover js-basic-example dataTable table-custom m-b-0">
                        <thead>
                            <tr>                                        
                                <th>Name</th>
                                <th></th>
                                <th></th>
                                <th>Created Date</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="width45">
                                    <img src="../assets/images/xs/avatar1.jpg" class="rounded-circle width35" alt="">
                                </td>
                                <td>
                                    <h6 class="mb-0">Marshall Nichols</h6>
                                    <span>marshall-n@gmail.com</span>
                                </td>
                                <td><span class="badge badge-danger">Super Admin</span></td>
                                <td>24 Jun, 2015</td>
                                <td>CEO and Founder</td>
                                <td>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="../assets/images/xs/avatar2.jpg" class="rounded-circle width35" alt="">
                                </td>
                                <td>
                                    <h6 class="mb-0">Susie Willis</h6>
                                    <span>sussie-w@gmail.com</span>
                                </td>
                                <td><span class="badge badge-info">Admin</span></td>
                                <td>28 Jun, 2015</td>
                                <td>Team Lead</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="../assets/images/xs/avatar3.jpg" class="rounded-circle width35" alt="">
                                </td>
                                <td>
                                    <h6 class="mb-0">Debra Stewart</h6>
                                    <span>debra@gmail.com</span>
                                </td>
                                <td><span class="badge badge-info">Admin</span></td>
                                <td>21 July, 2015</td>
                                <td>Team Lead</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="../assets/images/xs/avatar4.jpg" class="rounded-circle width35" alt="">
                                </td>
                                <td>
                                    <h6 class="mb-0">Erin Gonzales</h6>
                                    <span>Erinonzales@gmail.com</span>
                                </td>
                                <td><span class="badge badge-default">Employee</span></td>
                                <td>21 July, 2015</td>
                                <td>Web Developer</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="../assets/images/xs/avatar3.jpg" class="rounded-circle width35" alt="">
                                </td>
                                <td>
                                    <h6 class="mb-0">Ava Alexander</h6>
                                    <span>alexander@gmail.com</span>
                                </td>
                                <td><span class="badge badge-success">HR Admin</span></td>
                                <td>21 July, 2015</td>
                                <td>HR</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Default Size -->
<div class="modal animated fadeIn" id="add_user" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="title" id="defaultModalLabel">Add User</h6>
            </div>
            <div class="modal-body">
                <div class="row clearfix">
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="First Name *">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Last Name">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Email ID *">
                        </div>
                    </div>    
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                   
                            <input type="text" class="form-control" placeholder="Username *">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Password">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Confirm Password">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Mobile No">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">
                            <select class="form-control show-tick">
                                <option>Select Role Type</option>
                                <option>Super Admin</option>
                                <option>Admin</option>
                                <option>Employee</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Employee ID *">
                        </div>
                    </div>
                    <div class="col-12">
                        <h6>Module Permission</h6>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Read</th>
                                        <th>Write</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Super Admin</td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Admin</td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                <span></span>
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Employee</td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                <span></span>
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>HR Admin</td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                <span></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="fancy-checkbox">
                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                <span></span>
                                            </label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Add</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/ui/dialogs.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>