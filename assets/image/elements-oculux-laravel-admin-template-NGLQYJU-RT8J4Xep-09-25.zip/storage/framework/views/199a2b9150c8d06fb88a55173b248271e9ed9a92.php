<?php $__env->startSection('parentPageTitle', 'App'); ?>
<?php $__env->startSection('title', 'Contact Grid'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_yellow">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar1.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Michelle Green</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-slack"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_indigo">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar2.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Jason Porter</h6>
                <span>Carol@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-skype"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-dribbble"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_pink">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar3.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Terry Carter</h6>
                <span>Michelle@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-slack"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_cyan">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar4.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Michelle Green</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-slack"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_red">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar5.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Michelle Green</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-slack"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_blue">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar6.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Michelle Green</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_green">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar1.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Denise Alvarado</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-slack"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="card c_grid c_cyan">
            <div class="body text-center">
                <div class="circle">
                    <img class="rounded-circle" src="../assets/images/sm/avatar2.jpg" alt="">
                </div>
                <h6 class="mt-3 mb-0">Terry Carter</h6>
                <span>jason-porter@info.com</span>
                <ul class="mt-3 list-unstyled d-flex justify-content-center">
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-flickr"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-dropbox"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-apple"></i></a></li>
                    <li><a class="p-3" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                </ul>
                <button class="btn btn-default btn-sm">Follow</button>
                <button class="btn btn-default btn-sm">Message</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>