<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon"> <!-- Favicon-->
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', config('app.name')); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', config('app.name')); ?>">
    <?php echo $__env->yieldContent('meta'); ?>

    <?php echo $__env->yieldPushContent('before-styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">    

    <?php echo $__env->yieldPushContent('after-styles'); ?>    
    <?php if(trim($__env->yieldContent('page-styles'))): ?>    
        <?php echo $__env->yieldContent('page-styles'); ?>
    <?php endif; ?>
    
    <!-- Custom Css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/color_skins.css')); ?>">
</head>

<?php 
    $setting = !empty($_GET['theme']) ? $_GET['theme'] : '';
    $theme = "theme-orange";
    $menu = "";
    if ($setting == 'p') {
        $theme = "theme-purple";
    } else if ($setting == 'b') {
        $theme = "theme-blue";
    } else if ($setting == 'g') {
        $theme = "theme-green";
    } else if ($setting == 'c') {
        $theme = "theme-cyan";
    } else if ($setting == 'bl') {
        $theme = "theme-blush";
    } else {
            $theme = "theme-orange";
    }
?>

<body class="<?= $theme ?>">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30"><img src="<?php echo e(asset('assets/images/logo-icon.svg')); ?>" width="48" height="48" alt="Lucid"></div>
            <p>Please wait...</p>        
        </div>
    </div>

    <div id="wrapper">

        <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?php echo $__env->yieldContent('title'); ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="icon-home"></i></a></li>
                                <?php if(trim($__env->yieldContent('parentPageTitle'))): ?>
                                    <li class="breadcrumb-item"><?php echo $__env->yieldContent('parentPageTitle'); ?></li>
                                <?php endif; ?>
                                <?php if(trim($__env->yieldContent('title2'))): ?>
                                    <li class="breadcrumb-item"><?php echo $__env->yieldContent('title2'); ?></li>
                                <?php endif; ?>
                                <?php if(trim($__env->yieldContent('title'))): ?>
                                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>            
                        <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                            <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#00c5dc"
                                    data-fill-Color="transparent">3,5,1,6,5,4,8,3</div>
                                <span>Visitors</span>
                            </div>
                            <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                                <div class="sparkline text-left" data-type="line" data-width="8em" data-height="20px" data-line-Width="1" data-line-Color="#f4516c"
                                    data-fill-Color="transparent">4,6,3,2,5,6,5,4</div>
                                <span>Visits</span>
                            </div>
                        </div>
                    </div>
                </div>                
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <?php echo $__env->yieldPushContent('before-scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>    
    <script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('after-scripts'); ?>
    
    <?php if(trim($__env->yieldContent('page-script'))): ?>
        <?php echo $__env->yieldContent('page-script'); ?>
    <?php endif; ?>    
</body>
</html>
