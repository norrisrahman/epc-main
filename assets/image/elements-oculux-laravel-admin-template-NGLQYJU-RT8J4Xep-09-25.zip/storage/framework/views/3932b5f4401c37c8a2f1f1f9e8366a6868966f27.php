<?php $__env->startSection('title', 'Maintenance'); ?>


<?php $__env->startSection('content'); ?>
<div id="wrapper">
    <div class="vertical-align-wrap">
        <div class="vertical-align-middle maintenance">
        <div class="text-center">
            <article>
                <h1>We&rsquo;ll be back soon!</h1>
                <div>
                    <p>Sorry for the inconvenience<br> but we&rsquo;re performing some maintenance at the moment.<br> If you need to you can always <a href="mailto:#">contact us</a>, otherwise we&rsquo;ll be back online shortly!</p>
                    <p>&mdash; The Team</p>
                </div>
            </article>
            <div class="margin-top-30">
                <a href="javascript:history.go(-1)" class="btn btn-default"><i class="fa fa-arrow-left"></i><span>Go Back</span></a>
                <a href="<?php echo e(route('mypage.index')); ?>" class="btn btn-info"><i class="fa fa-home"></i><span>Home</span></a>
            </div>
        </div>
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>