@extends('layout.master')
@section('parentPageTitle', 'Pages')
@section('title', 'User List')


@section('content')
<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="body">
                <span>Coming Soon</span>
                <h4>Page Under Construction</h4>
            </div>
        </div>
    </div>
</div>

@stop

@section('page-styles')
@stop

@section('page-script')
<script src="{{ asset('assets/bundles/mainscripts.bundle.js') }}"></script>
@stop